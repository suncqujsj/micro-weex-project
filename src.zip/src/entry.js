import App from './App.vue'

App.el = '#root'
new Vue(App)

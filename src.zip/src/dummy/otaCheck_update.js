export default{
  "msgid":"xxxxx",
  "errorCode":"0",
  "data":{
	    "latest_ver":"000000000328",			 /*当前最新版本id*/
		 "latest_ver_desc":"fdsfsad<br>323232",    /*当前最新版本描述信息*/
		 "latest_ver_url":"xxxxx",	  /*最新版本的下载url*/
		  "device_ver":"000000000328",			 /*当前网关设备的版本信息*/
		  "pkg_md5":"xxxx"			 /*最新包的md5*/
   }
};
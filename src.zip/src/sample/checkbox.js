
const App = require("./checkbox.vue")
App.el = '#root'
new Vue(App)

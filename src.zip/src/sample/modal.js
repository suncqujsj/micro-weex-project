
const App = require("./modal.vue")
App.el = '#root'
new Vue(App)

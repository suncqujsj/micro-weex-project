
const App = require("./radio.vue")
App.el = '#root'
new Vue(App)

export default{
    "errorCode": "0",
    "error_msg": "ok",
    "msgid": "77753526",
    "data": {
		"state":[
		{
		   "endpoint":1,
           "bound"://�󶨹�ϵ���������ʾ�ް�
			[
				{
						"nodeid":1009,
						"endpoint":1,
				},
				{
						"nodeid":1010,
						"endpoint":4,
				}
		    ]
		},
		{
		   "endpoint":2,
		   "bound":[]
		},
		{
		   "endpoint":3,
		   "bound":[]
		},
		{
		   "endpoint":4,
		   "bound":[]
		}
	   ]
     }
}
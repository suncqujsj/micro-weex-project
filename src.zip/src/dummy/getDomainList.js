export default{
    "errorCode": 0,
    "msg": "ok",
    "msgid": "56364095",
    "data": {
        "domains": [
            {
                "domain_id": "1",
                "domain_image": "",
                "domain_name": "客厅",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "2",
                "domain_image": "1",
                "domain_name": "卧室",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "3",
                "domain_image": "2",
                "domain_name": "厨房",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "4",
                "domain_image": "4",
                "domain_name": "区1",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "5",
                "domain_image": "3",
                "domain_name": "区2",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "6",
                "domain_image": "0",
                "domain_name": "区3",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "7",
                "domain_image": "0",
                "domain_name": "区4",
                "houseid": "198",
                "userid": "138587"
            },
            {
                "domain_id": "8",
                "domain_image": "0",
                "domain_name": "区5",
                "houseid": "198",
                "userid": "138587"
            }
        ]
    }
}

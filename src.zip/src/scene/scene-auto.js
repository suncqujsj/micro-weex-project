import entry from './scene-auto.vue'

entry.el = '#root'
export default new Vue(entry)
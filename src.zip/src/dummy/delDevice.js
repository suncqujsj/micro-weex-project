export default{
   "msgid":"xxxxx",
   "errorCode":"0",
   "nid":"xxxxxxx"
}
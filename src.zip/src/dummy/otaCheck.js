export default {
  "msgid":"xxxxx",
  "errorCode":"0",
  "data":{
	     "latest_ver":"000000000328",			 /*当前最新版本id*/
		 "latest_ver_desc":"1、智能连接：除可以连接美的集团全品类智能家电外，还可连接美的智能网关及其zigbee子设备。",    /*当前最新版本描述信息*/
		 "latest_ver_url":"http://midea-file-test",	  /*最新版本的下载url*/
		  "device_ver":"000000000320",			 /*当前网关设备的版本信息*/
		  "pkg_md5":"xxxx"			 /*最新包的md5*/
   }
};
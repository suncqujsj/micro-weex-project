
const App = require("./progress.vue")
App.el = '#root'
new Vue(App)

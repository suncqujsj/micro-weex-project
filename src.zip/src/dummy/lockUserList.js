export default{
     "msgid":"xxxxxxx",
	 "errorCode":0,
	 "msg":"msgcontent",
	 "data":{
			"userInfos":
			   [
				  {
					"userType":"1",//用户类型
					"userNo":"1",//用户编号
					"userRole": "张校长"//用户角色
				  },
				  {
					"userType":"2",//用户类型
					"userNo":"1",//用户编号
					"userRole": ""//用户角色
				  },
				  {
					"userType":"1",//用户类型
					"userNo":"33",//用户编号
					"userRole": "爸爸"//用户角色
				  },
				  {
					"userType":"1",//用户类型
					"userNo":"2",//用户编号
					"userRole": ""//用户角色
				  },
				  {
					"userType":"1",//用户类型
					"userNo":"3",//用户编号
					"userRole": "爸爸"//用户角色
				  }
				  /*{
					"userType":"1",//用户类型
					"userNo":"25",//用户编号
					"userRole": ""//用户角色
				  }*/
				  
		 ]
	   }
}


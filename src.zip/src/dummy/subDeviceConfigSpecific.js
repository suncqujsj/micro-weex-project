export default  {
    "msgid": "xxxxx",
    "errorCode": "0",
    "data": {

    }
}


const App = require("./navList.vue")
App.el = '#root'
new Vue(App)


const App = require("./list.vue")
App.el = '#root'
new Vue(App)

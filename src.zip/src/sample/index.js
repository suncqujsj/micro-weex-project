
const App = require("./index.vue")
App.el = '#root'
new Vue(App)

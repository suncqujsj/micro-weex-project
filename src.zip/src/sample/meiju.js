
const App = require("./meiju.vue")
App.el = '#root'
new Vue(App)

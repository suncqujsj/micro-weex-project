
const App = require("./popup.vue")
App.el = '#root'
new Vue(App)

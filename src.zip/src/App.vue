<template>
  <index-page></index-page>
</template>

<script>
  //import IndexPage from './component/test.vue'
  import IndexPage from './sample/index.vue'

  export default {
    components: { IndexPage }
  } 
</script>

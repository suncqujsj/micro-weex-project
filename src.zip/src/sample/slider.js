import entry from './slider.vue'

entry.el = '#root'
export default new Vue(entry)


const App = require("./dialog.vue")
App.el = '#root'
new Vue(App)

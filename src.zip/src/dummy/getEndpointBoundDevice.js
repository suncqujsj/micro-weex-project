export default{
    "errorCode": "0",
    "error_msg": "ok",
    "msgid": "77753526",
    "data": {
        "bound"://�󶨹�ϵ���������ʾ�ް�
			[
				{
				 		"nodeid":1009,
				 		"endpoint":3,
				},
				{
				 		"nodeid":1025,
				 		"endpoint":1
				}
            ]
     }
}



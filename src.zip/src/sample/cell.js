
const App = require("./cell.vue")
App.el = '#root'
new Vue(App)

/**
 * Created by sf
 * 2018/10/26
 */

module.exports = {
    device: {
        type: 0xB2,
        widget_name: 'MSO_T0xB2_0TPN50QL',
        widget_version: '1.0.0'
    }
};
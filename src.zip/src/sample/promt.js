
const App = require("./promt.vue")
App.el = '#root'
new Vue(App)

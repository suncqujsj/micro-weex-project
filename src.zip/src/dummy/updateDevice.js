export default{
    "msgid": "13356126",
    "errorCode": "0",
    "nid": "00158D0000D77512",
    /*"data": {
         "modelid": "485_midea.cac.001",
         "guard": 0,
         "status": 1,
		 "endlist": [
			 {
			  "endpoint": 1,
			  "event": {
					"OnOff": 1,
					"operationMode" :2,
					"windSpeed":2,
					"currTemp":30,
					"targetTemp":25,
					"yDirection":1,
					"airExchange":0,
					"powerSave":0,
					"PTCHeat":0
			 }
		   }
		 ]
     }*/

		/*"data":{
            "node": "00158D00012E26D9",
            "modelid": "kaadas.doorlock.001",
            "guard": 0,
            "status": 1,
			"lowBattery":1,
            "endlist": [{
               "event": { 
				   "ZoneStatus": 0
				  
			   }
            }]
        } */
	"data":{
            "node": "00158D00012E26D9",
            "modelid": "jiayun.magnet.001",
            "guard": 0,
            "status": 1,
            "version":"1.1",
			"lowBattery":1,
            "endlist": [{
               "event": { 
				   "ZoneStatus": 0
				}
            }]
    }
       
	/*"data":{
            "node": "00158D00012E26D9",
            "modelid": "jiayun.magnet.001",
            "guard": 0,
            "status": 1,
			"version":xxx,
            "endlist": [{
               "event": { 
				   "OnOff": 1,
				   "currTemp":27,
					"operationMode" :3,
					 "windSpeed":2,
					 "targetTemp":25
			   }
            }]
        }
      */
    /* "data": {
         "modelid": "midea.switch.005",
		 "version":"11",
         "guard": 0,
         "status": 1,
          "endlist": [{
			   "endpoint": 5,
			   "event": {
                 "currTemp": 2445,
                 "currHum":2032
               }
		     }
		   ]
		 }
     */
     
    //     "data": {
    //     "modelId": "jiayun.curtain.001",
    //     "guard": 0,
    //     "status": 1,
    //     "endlist": [{
    //         "endpoint": 1,
    //         "event": {
    //             "OnOff": 1
    //         }
    //     }]
    // }

	/*"data": {
         "modelid": "laffey.switch.001",
         "guard": 0,
         "status": 1,
         "endlist": [{
             "endpoint": 1,
             "event": {
                "OnOff": 1
            }
        }]
      }*/

/*
		 "data": {
		     "modelId": "luftmon.alphair.001",
		     "guard": 0,
		     "status": 1,

		     "endpoint": 1,
			"endlist": [
				{
					 "event": {
						 "currTemp": 23,
						 "targetTemp": 33,
						 "operationMode":2,
						 "OnOff":1,
						 
							
					 }
				}
		   ]

		 }
*/
    // "data": {
    //     "modelId": "jiayun.switch.005",
    //     "guard": 0,
    //     "status": 1,
    //     "endlist": [{ "endpoint": 1, "event": { "OnOff": 1 } },
    //         { "endpoint": 2, "event": { "OnOff": 0 } },
    //         { "endpoint": 3, "event": { "OnOff": 1 } },
    //         { "endpoint": 4, "event": { "OnOff": 0 } }
    //     ]
    // }

	/*"data": {
        "status": 1, 
        "endlist": [
            {
                "event": {
                     "OnOff": 0,
					 "Level":10
                }, 
                "endpoint":2
            },
			{
                "event": {
                     "OnOff": 1,
					 "Level":12
                }, 
                "endpoint":1
            }
        ], 
        "nodeid": "00158D000150DA65", 
        "guard": 0, 
        "modelid": "jiayun.light.002"
    }*/
	



  /*"data": {
        "modelid": "dooya.curtain.001",
		"nodeid":"",
        "guard": 0,
        "status": 1,
        "endlist": [{
            "endpoint": 1,
            "event": {
                 "Level":10,
				 "OnOff":1
            }
          }
		]
    }*/
}

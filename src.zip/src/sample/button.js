
const App = require("./button.vue")
App.el = '#root'
new Vue(App)

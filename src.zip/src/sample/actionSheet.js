
const App = require("./actionSheet.vue")
App.el = '#root'
new Vue(App)

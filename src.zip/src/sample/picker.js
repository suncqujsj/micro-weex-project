
const App = require("./picker.vue")
App.el = '#root'
new Vue(App)

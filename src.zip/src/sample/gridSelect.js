
const App = require("./gridSelect.vue")
App.el = '#root'
new Vue(App)

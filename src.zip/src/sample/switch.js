
const App = require("./switch.vue")
App.el = '#root'
new Vue(App)

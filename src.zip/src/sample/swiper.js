
const App = require("./swiper.vue")
App.el = '#root'
new Vue(App)

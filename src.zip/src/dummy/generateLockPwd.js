export default
{
    "msgid":"xxxxx",
	"errorCode" :0,
	"msg":"msgcontent",
	"data": {
		"passcode": "123456",
		"expire":600
	}
}

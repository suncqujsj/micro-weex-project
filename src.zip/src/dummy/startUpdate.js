export default {
  "msgid":"xxxxx",
  "errorCode":"0",
  "data":{
	    "latest_ver":"xxx",			 /*当前最新版本id*/
		"latest_ver_url":"xxxxx",   /*最新版本的下载url*/
		"pkg_md5":"xxxxx"
    }
};
// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 830);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _debugUtil = __webpack_require__(1);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _util = __webpack_require__(2);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mm = weex.requireModule('modal');
var navigator = weex.requireModule('navigator');
var stream = weex.requireModule('stream');
var storage = weex.requireModule('storage');
var bridgeModule = weex.requireModule('bridgeModule');
var globalEvent = weex.requireModule("globalEvent");

var isIos = weex.config.env.platform == "iOS" ? true : false;


var isDummy = false;
// import Mock from './mock'  //正式场上线时注释掉

var debugLogSeperator = "**************************************\n";

var ipParam = weex.config.bundleUrl.match(new RegExp("[\?\&]ip=([^\&]+)", "i"));
if (ipParam && ipParam.length > 1) {
    ipParam = ipParam[1];
    // 测试
    isDummy = true;
}
var platform = weex.config.env.platform;
if (platform == 'Web') {
    isDummy = true;
}
console.log("isDummy:" + isDummy);
var isRemote = weex.config.bundleUrl.indexOf("http") > -1 ? true : false;

exports.default = {
    serviceList: {
        test: "commonservice"
    },
    Mock: {},
    isDummy: isDummy,
    //**********Util方法***************START
    convertToJson: function convertToJson(str) {
        var result = str;
        if (typeof str == 'string') {
            try {
                result = JSON.parse(str);
            } catch (error) {
                console.error(error);
            }
        }
        return result;
    },
    getParameters: function getParameters(key) {
        var theRequest = new Object();
        var bundleUrl = weex.config.bundleUrl;
        var queryString = '';
        if (bundleUrl.indexOf("?") != -1) {
            queryString = bundleUrl.substr(bundleUrl.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },

    //**********Util方法***************END

    //**********页面跳转接口***************START
    /*
    params:
        path - 跳转页面路径（以插件文件夹为根目录的相对路径）
        options: {
            animated: true/false, - 是否需要跳转动画
            replace: true/false, - 跳转后是否在历史栈保留当前页面
            viewTag: string - 给跳转后的页面设置标识，可用于goBack时指定返回页面
            transparent: 'true/false', //新页面背景是否透明
            animatedType: 'slide_bottomToTop' //新页面出现动效类型
        }
    */
    goTo: function goTo(path, options) {
        var _this = this;

        var url;
        // mm.toast({ message: isRemote, duration: 2 })
        if (this.isDummy != true && !isRemote) {
            //手机本地页面跳转
            this.getPath(function (weexPath) {
                //weexPath为插件包地址，比如：files:///..../MideaHome/T0x99/
                url = weexPath + path;
                _this.runGo(url, options);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试跳转
            var theRequest = this.getParameters();
            var ip = theRequest['ip'];
            var root = theRequest['root'];
            var targetPath = path;
            if (targetPath.indexOf("?") != -1) {
                targetPath += '&root=' + root + '&ip=' + ip;
            } else {
                targetPath += '?root=' + root + '&ip=' + ip;
            }
            if (ip == null || ip.length < 1) {
                url = "http://localhost:8080/dist/" + root + '/' + targetPath;
            } else {
                url = "http://" + ip + ":8080" + "/dist/" + root + '/' + targetPath;
            }
            this.runGo(url, options);
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path.replace('?', '&');
        }
    },
    runGo: function runGo(url, options) {
        // mm.toast({ message: url, duration: 2 })
        if (!options) {
            options = {
                animated: 'true',
                replace: 'false'
            };
        } else {
            if (typeof options.animated == 'boolean') {
                options.animated = options.animated ? 'true' : 'false';
            }
            if (typeof options.replace == 'boolean') {
                options.replace = options.replace ? 'true' : 'false';
            }
        }
        var params = Object.assign(options, {
            url: url
        });
        // this.toast(params)
        navigator.push(params, function (event) {});
    },

    /*
        取得当前weex页面的根路径
    */
    getPath: function getPath(callBack) {
        if (this.isDummy != true) {
            bridgeModule.getWeexPath(function (resData) {
                var jsonData = JSON.parse(resData);
                var weexPath = jsonData.weexPath;
                callBack(weexPath);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试
            var theRequest = this.getParameters();
            var ip = theRequest['ip'];
            var root = theRequest['root'];
            var weexPath = void 0;
            if (ip == null || ip.length < 1) {
                weexPath = "http://localhost:8080/dist/" + root + '/';
            } else {
                weexPath = "http://" + ip + ":8080" + "/dist/" + root + '/';
            }
            callBack(weexPath);
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path;
        }
    },

    /*  
    options = {
            animated: 'true',
            animatedType: 'slide_topToBottom' //页面关闭时动效类型
    }*/
    goBack: function goBack() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var params = Object.assign({
            animated: 'true'
        }, options);
        // this.toast(params)
        navigator.pop(params, function (event) {});
    },
    backToNative: function backToNative() {
        bridgeModule.backToNative();
    },

    //**********页面跳转接口***************END


    //**********非APP业务接口***************START
    genMessageId: function genMessageId() {
        var messageId = '';
        for (var i = 0; i < 8; i++) {
            messageId += Math.floor(Math.random() * 10).toString();
        }
        return messageId;
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        var temp = void 0;
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            temp = JSON.stringify(value);
        }
        var defaultCallback = function defaultCallback(event) {
            console.log('set success');
        };
        storage.setItem(key, temp || value, callback || defaultCallback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, function () {
            if (callback) callback();
        });
    },
    toast: function toast(message, duration) {
        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            message = JSON.stringify(message);
        }
        mm.toast({ message: message, duration: duration || 1 });
    },
    alert: function alert(message, callback, okTitle) {
        var callbackFunc = callback || function (value) {};

        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            try {
                message = JSON.stringify(message);
            } catch (error) {}
        }
        mm.alert({
            message: message,
            okTitle: okTitle || "确定"
        }, function (value) {
            callbackFunc(value);
        });
    },
    confirm: function confirm(message, callback, okTitle, cancelTitle) {
        mm.confirm({
            message: message,
            okTitle: okTitle || '确定',
            cancelTitle: cancelTitle || '取消'
        }, function (result) {
            callback(result);
        });
    },
    showLoading: function showLoading() {
        if (this.isDummy != true) {
            bridgeModule.showLoading();
        }
    },
    hideLoading: function hideLoading() {
        if (this.isDummy != true) {
            bridgeModule.hideLoading();
        }
    },
    showLoadingWithMsg: function showLoadingWithMsg(option) {
        if (this.isDummy != true) {
            var params = option;
            if (typeof option == 'string') {
                params = {
                    msg: option
                };
            }
            bridgeModule.showLoadingWithMsg(params);
        }
    },
    hideLoadingWithMsg: function hideLoadingWithMsg() {
        if (this.isDummy != true) {
            bridgeModule.hideLoadingWithMsg();
        }
    },

    //**********非APP业务接口***************END

    //**********网络请求接口***************START
    //发送智慧云网络请求：此接口固定Post到智慧云https地址及端口
    sendMCloudRequest: function sendMCloudRequest(name, params) {
        var _this2 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var self = _this2;
            if (_this2.isDummy != true) {
                _this2.getItem("masterId", function (resdata) {
                    var msgid = self.genMessageId();
                    var masterId = resdata.data;
                    var sendData = {};
                    sendData.url = self.serviceList[name] ? self.serviceList[name] : name;
                    sendData.params = Object.assign({
                        applianceId: masterId + "",
                        msgid: msgid
                    }, params);
                    if (options.isShowLoading) {
                        _this2.showLoading();
                    }
                    bridgeModule.sendMCloudRequest(sendData, function (resData) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        if (options.isShowLoading) {
                            _this2.hideLoading();
                        }

                        if (options.isValidate) {
                            //resData.status为5.0判断；resData.errorCode为4.判断
                            if (resData.errorCode == 0) {
                                resolve(resData);
                            } else if (resData.status === true) {
                                resolve(resData);
                            } else {
                                reject(resData);
                            }
                        } else {
                            resolve(resData);
                        }
                    }, function (error) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                        if (options.isShowLoading) {
                            _this2.hideLoading();
                        }
                        if (typeof error == 'string') {
                            error = JSON.parse(error);
                        }
                        reject(error);
                    });
                });
            } else {
                var resData = _this2.Mock.getMock(self.serviceList[name] ? self.serviceList[name] : name);
                if (options.isValidate) {
                    //resData.status为5.0判断；resData.errorCode为4.判断
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else if (resData.status === true) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } else {
                    resolve(resData);
                }
            }
        });
    },


    //^5.0.0发送中台网络请求：此接口固定Post到中台https地址及端口
    sendCentralCloundRequest: function sendCentralCloundRequest(name, params) {
        var _this3 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true };

        return new Promise(function (resolve, reject) {
            if (_this3.isDummy != true) {
                var msgid = _this3.genMessageId();
                var sendData = params || {};
                sendData.url = _this3.serviceList[name] ? _this3.serviceList[name] : name;
                if (options.isShowLoading) {
                    _this3.showLoading();
                }
                bridgeModule.sendCentralCloundRequest(sendData, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        resData = JSON.parse(resData);
                    }
                    if (options.isShowLoading) {
                        _this3.hideLoading();
                    }

                    resolve(resData);
                }, function (error) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this3.hideLoading();
                    }
                    if (typeof error == 'string') {
                        error = JSON.parse(error);
                    }
                    reject(error);
                });
            } else {
                var resData = _this3.Mock.getMock(_this3.serviceList[name] ? _this3.serviceList[name] : name);
                resolve(resData);
            }
        });
    },

    //发送POST网络请求：URL自定义
    /* params: {
        url: url,
        type: 'text',
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: {
            'objectId': objectId,
            'format': 'base64'
        }
    } */
    sendHttpRequest: function sendHttpRequest(params) {
        var _this4 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var requestParams = JSON.parse(JSON.stringify(params));
            var self = _this4;
            if (_this4.isDummy != true) {
                var defaultParams = {
                    method: "POST",
                    type: 'json'
                };
                requestParams = Object.assign(defaultParams, requestParams);

                /* body 参数仅支持 string 类型的参数，请勿直接传递 JSON，必须先将其转为字符串。
                GET 请求不支持 body 方式传递参数，请使用 url 传参。 */
                if (requestParams.body && requestParams.method == "GET") {
                    var bodyStr = _this4.convertRequestBody(requestParams.body);
                    if (requestParams.url.indexOf("?") > -1) {
                        requestParams.url += "&" + bodyStr;
                    } else {
                        requestParams.url += "?" + bodyStr;
                    }
                    requestParams.body = "";
                } else if (requestParams.body && requestParams.method == "POST") {
                    requestParams.body = requestParams.body;
                }

                if (options.isShowLoading) {
                    _this4.showLoading();
                }
                var msgid = self.genMessageId();
                stream.fetch(requestParams, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', requestParams);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }
                    if (!resData.ok) {
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        reject(resData);
                    } else {
                        var result = resData.data;
                        if (typeof result == 'string') {
                            result = JSON.parse(result);
                        }
                        resolve(result);
                    }
                });
            } else {
                var resData = _this4.Mock.getMock(params.url);
                resolve(resData);
            }
        });
    },
    convertRequestBody: function convertRequestBody(obj) {
        var param = "";
        for (var name in obj) {
            if (typeof obj[name] != 'function') {
                param += "&" + name + "=" + encodeURI(obj[name]);
            }
        }
        return param.substring(1);
    },

    //发送指令透传接口
    startCmdProcess: function startCmdProcess(name, messageBody, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },


    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/
    isCreateListener: false,
    createCallbackFunctionListener: function createCallbackFunctionListener() {
        var _this5 = this;

        if (!this.isCreateListener) {
            this.isCreateListener = true;
            globalEvent.addEventListener("callbackFunction", function (result) {
                //IOS消息返回处理
                var commandId = result.commandId;
                if (commandId) {
                    _this5.callbackFunction(commandId, result);
                }
            });
        }
    },

    callbackFunctions: {},
    callbackFailFunctions: {},
    callbackFunction: function callbackFunction(commandId, result) {
        var jsonResult = result;
        var cbf = this.callbackFunctions[commandId];
        var cbff = this.callbackFailFunctions[commandId];
        if (jsonResult.errorCode !== undefined && jsonResult.errMessage == 'TimeOut') {
            if (typeof cbff == "function") {
                cbff(-1); //表示指令超时 －1
            }
        } else {
            if (typeof cbf == "function") {
                cbf(jsonResult);
            }
        }
        delete this.callbackFunctions[commandId];
        delete this.callbackFailFunctions[commandId];
    },

    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/

    //发送Lua指令接口
    sendLuaRequest: function sendLuaRequest(params) {
        var _this6 = this;

        var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

        return new Promise(function (resolve, reject) {
            var param = {};
            param.operation = params.operation || "luaControl"; //luaQuery or luaControl
            param.params = params.data || {};
            if (_this6.isDummy != true) {
                if (isShowLoading) {
                    _this6.showLoading();
                }
                var msgid = _this6.genMessageId();
                bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', param);
                    _debugUtil2.default.debugLog('Lua response(' + msgid + '):', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        resData = JSON.parse(resData);
                    }
                    if (isShowLoading) {
                        _this6.hideLoading();
                    }
                    if (resData.errorCode == 0) {
                        //成功
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                }, function (error) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', param);
                    _debugUtil2.default.debugLog('=======> Lua error(' + msgid + '): ', error, debugLogSeperator);
                    if (isShowLoading) {
                        _this6.hideLoading();
                    }
                    if (typeof error == 'string') {
                        error = JSON.parse(error);
                    }
                    reject(error);
                });
            } else {
                var resData = void 0;

                if (params['operation'] || params['name']) {
                    if (params['name']) {
                        resData = Mock.getMock(params['name']);
                    } else {
                        resData = Mock.getMock(params['operation']);
                    }
                }
                _debugUtil2.default.debugLog("Mock: ", resData);
                resolve(resData);
            }
        });
    },

    //**********网络请求接口***************END


    //**********APP业务接口***************START
    updateTitle: function updateTitle(title, showLeftBtn, showRightBtn) {
        var params = {
            title: title,
            showLeftBtn: showLeftBtn,
            showRightBtn: showRightBtn
        };
        if (this.isDummy != true) {
            bridgeModule.updateTitle(JSON.stringify(params));
        }
    },
    showSharePanel: function showSharePanel(params, callback, callbackFail) {
        return new Promise(function (resolve, reject) {
            bridgeModule.showSharePanel(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },


    //统一JS->Native接口
    commandInterfaceWrapper: function commandInterfaceWrapper(param) {
        var _this7 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                resolve(_this7.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //获取用户信息
    getUserInfo: function getUserInfo() {
        var param = {
            operation: 'getUserInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //打电话
    /* param: {
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    } */
    callTel: function callTel(params) {
        var param = Object.assign(params, {
            operation: 'callTel'
        });
        return this.commandInterfaceWrapper(param);
    },

    //触发手机震动
    hapticFeedback: function hapticFeedback() {
        var param = {
            operation: 'hapticFeedback'
        };
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的系统设置，比如蓝牙
    openNativeSystemSetting: function openNativeSystemSetting(settingName) {
        var param = {
            operation: 'openNativeSystemSetting',
            setting: settingName || 'bluetooth'
        };
        return this.commandInterfaceWrapper(param);
    },
    shareMsg: function shareMsg(params) {
        /* params =  {
            "type": "wx", //分享类型，wx表示微信分享，qq表示qq分享，sms表示短信分享，weibo表示新浪微博，qzone表示QQ空间，wxTimeline表示微信朋友圈
            "title": "xxxxxx", //分享的标题
            "desc": "xxxxxx",//分享的文本内容
            "imgUrl": "xxxxxx",//分享的图片链接
            "link": "xxxxxx" //分享的跳转链接
        } */
        var param = {
            'operation': 'shareMsg',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备网络信息
    getNetworkStatus: function getNetworkStatus() {
        var param = {
            operation: 'getNetworkStatus'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前家庭信息
    getCurrentHomeInfo: function getCurrentHomeInfo() {
        var param = {
            operation: 'getCurrentHomeInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备信息
    getDeviceInfo: function getDeviceInfo() {
        var param = {
            operation: 'getDeviceInfo'
        };
        if (this.isDummy == true) {
            return new Promise(function (resolve, reject) {
                var resData = Mock.getMock(param.operation);
                if (resData.errorCode == 0) {
                    resolve(resData);
                } else {
                    reject(resData);
                }
            });
        } else {
            return this.commandInterfaceWrapper(param);
        }
    },

    //更新当前设备信息
    updateDeviceInfo: function updateDeviceInfo(params) {
        var param = Object.assign(params, {
            operation: 'updateDeviceInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的原生页面
    jumpNativePage: function jumpNativePage(params) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "data": {xxxxxx}, //传参，为json格式字符串
        } */
        var param = Object.assign(params, {
            operation: 'jumpNativePage'
        });
        return this.commandInterfaceWrapper(param);
    },

    //跳转到h5页面
    weexBundleToWeb: function weexBundleToWeb(params) {
        /* params =  {
            url: "xxxx", //跳转的目标页面
            titel: "h5标题"
        } */
        var param = Object.assign(params, {
            operation: 'weexBundleToWeb'
        });
        return this.commandInterfaceWrapper(param);
    },

    //设置是否监控安卓手机物理返回键功能, v4.4.0
    setBackHandle: function setBackHandle(status) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "isMonitor": on,  //on: 打开监控，off: 关闭监控
        } */
        var params = {
            operation: 'setBackHandle',
            isMonitor: status
        };
        return this.commandInterfaceWrapper(params);
    },

    //二维码/条形码扫码功能，用于读取二维码/条形码的内容
    scanCode: function scanCode(status) {
        var params = {
            operation: 'scanCode'
        };
        return this.commandInterfaceWrapper(params);
    },

    //开启麦克风录音，可以保存录音文件或者把声音转换成文字
    startRecordAudio: function startRecordAudio(params) {
        /* params =  {
            max:number, //最长录音时间, 单位为秒
            isSave:true/false, //是否保存语音录音文件
            isTransform:true/false, //是否需要转换语音成文字
        } */
        var param = Object.assign(params, {
            operation: 'startRecordAudio'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音后，自行控制结束录音
    stopRecordAudio: function stopRecordAudio() {
        var params = {
            operation: 'stopRecordAudio'
        };
        return this.commandInterfaceWrapper(params);
    },
    takePhoto: function takePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'takePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },
    choosePhoto: function choosePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'choosePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },
    getGPSInfo: function getGPSInfo(params) {
        /* params =  {
            desiredAccuracy: "10",  //定位的精确度，单位：米
            alwaysAuthorization: "0",  //是否开启实时定位功能，0: 只返回一次GPS信息（默认），1:APP在前台时，每移动distanceFilter的距离返回一次回调。2:无论APP在前后台，每移动distanceFilter的距离返回一次回调（注意耗电）
            distanceFilter: "10", //alwaysAuthorization为1或2时有效，每移动多少米回调一次定位信息
        } */
        var param = Object.assign(params, {
            operation: 'getGPSInfo'
        });
        return this.commandInterfaceWrapper(param);
    },
    getCityInfo: function getCityInfo(params) {
        var param = Object.assign(params, {
            operation: 'getCityInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0 根据getCityInfo获得的城市对应的气象局ID获取城市天气信息， 比如温度， 风向等信息 */
    getWeatherInfo: function getWeatherInfo(params) {
        var param = Object.assign(params, {
            operation: 'getWeatherInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取登录态信息
    getLoginInfo: function getLoginInfo() {
        var param = {
            operation: 'getLoginInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    /* ^5.0.0 打开用户手机地图软件，传入标记地点。（打开地图软件后，用户可以使用地图软件的功能，比如导航等）
    ios: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转Safar，使用网页导航
    android: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转使用外部浏览器，使用网页导航（用户选择合适的浏览器，原生toast引导，存在选择错误应用的风险） */
    launchMapApp: function launchMapApp(params) {
        /* params =  {
            from:{ //当前用户地点
                latitude: string, //纬度
                longitude: string //经度
            },
            to:{ //目的地地点
                latitude: string, //纬度
                longitude: string //经度
            }
        } */
        var param = Object.assign(params, {
            operation: 'launchMapApp'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 根据模糊地址，返回地图服务的查询结果数据。 */
    searchMapAddress: function searchMapAddress(params) {
        /* params =  {
            city: "", //需要查询的城市(范围)
            keyword: "美的" //需要查询的地址
        } */
        var param = Object.assign(params, {
            operation: 'searchMapAddress'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择通讯录的好友，可以获取电话号码，好友信息 */
    getAddressBookPerson: function getAddressBookPerson() {
        var param = {
            operation: 'getAddressBookPerson'
        };
        return this.commandInterfaceWrapper(param);
    },

    //调用第三方SDK统一接口
    interfaceForThirdParty: function interfaceForThirdParty() {
        bridgeModule.interfaceForThirdParty.apply(bridgeModule, arguments);
    }
    //**********APP业务接口***************END

};

/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// ************ debug 相关 *************
var storage = weex.requireModule('storage');
var mm = weex.requireModule('modal');
var debugInfoDataChannel = new BroadcastChannel('debugInfoDataChannel');
var debugUtil = {
    isEnableDebugInfo: true,
    debugInfoKey: 'debugInfo',
    debugInfoDataChannel: debugInfoDataChannel,
    debugInfoExist: '',
    debugInfo: '',
    debugLogSizeLmite: 50000,
    debugLog: function debugLog() {
        var _this = this;

        for (var _len = arguments.length, messages = Array(_len), _key = 0; _key < _len; _key++) {
            messages[_key] = arguments[_key];
        }

        if (!this.isEnableDebugInfo) return;

        if (!this.debugInfoExist) {
            this.getDebugLog().then(function (data) {
                _this.debugInfoExist = data || ' ***>>> ';
                _this.debugLog.apply(_this, messages);
            });
        } else {
            var debugInfoArray = [];
            for (var index = 0; index < messages.length; index++) {
                var message = messages[index];
                if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
                    try {
                        message = JSON.stringify(message, null, 2);
                    } catch (error) {
                        debugInfoArray.push(error);
                    }
                } else if (typeof message == 'string') {
                    try {
                        message = JSON.stringify(JSON.parse(message), null, 2);
                    } catch (error) {}
                }
                debugInfoArray.push(message);
            }
            var newDebugInfo = new Date() + '\n' + debugInfoArray.join(", ") + '\n\n';
            this.debugInfo += newDebugInfo;
            this.setItem(this.debugInfoKey, this.debugInfoExist + this.debugInfo);
        }
    },
    getDebugLog: function getDebugLog() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            _this2.getItem(_this2.debugInfoKey, function (resp) {
                var result = resp.data || '';
                resolve(result.substr(-_this2.debugLogSizeLmite));
            });
        });
    },
    resetDebugLog: function resetDebugLog() {
        this.debugInfoExist = '';
        this.debugInfo = '';
    },
    cleanDebugLog: function cleanDebugLog() {
        var _this3 = this;

        this.debugInfoExist = '***';
        this.debugInfo = '';
        return new Promise(function (resolve, reject) {
            _this3.removeItem(_this3.debugInfoKey, function () {
                _this3.debugInfoExist = '***';
                _this3.debugInfo = '';
                resolve();
            });
        });
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            value = JSON.stringify(value);
        }
        value = value.substr(-this.debugLogSizeLmite);
        storage.setItem(key, value, callback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, callback);
    }
};

debugInfoDataChannel.onmessage = function (event) {
    debugUtil.cleanDebugLog();
};

exports.default = debugUtil;

/***/ }),

/***/ 14:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  extend: function extend(targetObj, fromObj) {
    fromObj = fromObj || {};
    targetObj = targetObj || {};
    for (var key in fromObj) {
      if (fromObj.hasOwnProperty(key) && !targetObj.hasOwnProperty(key)) {
        targetObj[key] = fromObj[key];
      }
    }
    return targetObj;
  }
};

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  arrowIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWBAMAAAA2mnEIAAAAMFBMVEUAAAAgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyXxqNxkAAAAEHRSTlMATEYxFA4CPTgqCUMlIhsZEJGcAQAAAE5JREFUGNNjAIKLDxjgQFAewT4o6ABncwqKICQmIkkwC6oiJAyFArBKsDUKLYBzMgR3ISQKxTHZCDUIvQgzMe1CCCPchnAzwi+YfkT4HQA98hAFt122dQAAAABJRU5ErkJggg==",
  extendIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAJCAMAAAA1k+1bAAAAM1BMVEUAAACYmJiXl5eZmZmampqYmJiYmJiXl5eZmZmYmJiYmJiZmZmZmZmYmJibm5ubm5uZmZlAoLvfAAAAEHRSTlMA9fZuSmhhUfhzVziEQ0IhhORZQgAAAEJJREFUCNdFyzkSwCAMQ1Ehg9my6P6nTeF4eI3mFwJsTjNrrbn7hS2NUX4CHipxAajM6sDpUhE6o9KieOPYil96Yz7ijwK/GAbG3wAAAABJRU5ErkJggg=="
};

/***/ }),

/***/ 170:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(171)
)

/* script */
__vue_exports__ = __webpack_require__(172)

/* template */
var __vue_template__ = __webpack_require__(173)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-rooms\\components\\scrollPicker.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7bff3296"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 171:
/***/ (function(module, exports) {

module.exports = {
  "wrap": {
    "flexDirection": "row",
    "backgroundColor": "#ffffff"
  },
  "scroller": {
    "flex": 1,
    "alignContent": "center",
    "alignItems": "center"
  },
  "list-item": {
    "width": 300,
    "height": 70,
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#000000",
    "textAlign": "center",
    "paddingTop": 8,
    "paddingRight": 8,
    "paddingBottom": 8,
    "paddingLeft": 8
  },
  "first-item": {
    "marginTop": 140
  },
  "last-item": {
    "marginBottom": 140
  },
  "first-visible-item": {
    "opacity": 0.3
  },
  "second-visible-item": {
    "opacity": 0.6
  },
  "second-last-visible-item": {
    "opacity": 0.6
  },
  "first-last-visible-item": {
    "opacity": 0.3
  },
  "selected-item": {
    "opacity": 1,
    "color": "#000000"
  },
  "unselected-item": {
    "opacity": 0.6,
    "color": "#000000"
  },
  "select-area": {
    "position": "absolute",
    "top": 136,
    "left": 0,
    "height": 72,
    "borderTopColor": "#e2e2e2",
    "borderTopWidth": 1,
    "borderBottomColor": "#e2e2e2",
    "borderBottomWidth": 1
  }
}

/***/ }),

/***/ 172:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _nativeService = __webpack_require__(0);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var dom = weex.requireModule('dom'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        listArray: {
            type: Array,
            default: function _default() {
                return [];
            }
        },
        itemIndex: {
            type: Number,
            default: 0
        },
        wrapHeight: {
            type: Number,
            default: 350
        },
        wrapWidth: {
            type: Number,
            default: 750
        }
    },
    computed: {
        wrapStyle: function wrapStyle() {
            return {
                width: this.wrapWidth,
                height: this.wrapHeight
            };
        }
    },
    data: function data() {
        return {
            itemHeight: 70
        };
    },

    methods: {
        scroll: function scroll(event) {
            var offsetY = event.contentOffset.y || '';
            if (offsetY % this.itemHeight != 0) {
                var firstVisibleItemIndex = Math.abs(Math.round(offsetY / 70));
                this.itemIndex = firstVisibleItemIndex;
            }
        },
        scrollEnd: function scrollEnd(event) {
            var el = this.$refs['item'][0];
            dom.scrollToElement(el, { offset: this.itemIndex * 70 });
            this.$emit('onChange', this.listArray[this.itemIndex]);
        }
    },
    mounted: function mounted() {},
    created: function created() {}
};

/***/ }),

/***/ 173:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrap"],
    style: _vm.wrapStyle
  }, [_c('div', {
    staticClass: ["select-area"]
  }), _c('scroller', {
    staticClass: ["scroller"],
    attrs: {
      "showScrollbar": "false"
    },
    on: {
      "scroll": _vm.scroll,
      "scrollend": _vm.scrollEnd
    }
  }, _vm._l((_vm.listArray), function(item, index) {
    return _c('div', {
      key: index,
      ref: "item",
      refInFor: true
    }, [_c('text', {
      class: [
        'list-item',
        index == 0 ? 'first-item' : '',
        index == (_vm.listArray.length - 1) ? 'last-item' : '',
        index == _vm.itemIndex - 2 ? 'first-visible-item' : '',
        index == _vm.itemIndex - 1 ? 'second-visible-item' : '',
        index == _vm.itemIndex ? 'selected-item' : 'unselected-item',
        index == _vm.itemIndex + 1 ? 'second-last-visible-item' : '',
        index == _vm.itemIndex + 2 ? 'first-last-visible-item' : ''
      ]
    }, [_vm._v(_vm._s(item.value))])])
  }))])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// ************ push 相关 *************
var util = {
    dateFormat: function dateFormat(dateTime, fmt) {
        // 对Date的扩展，将 Date 转化为指定格式的String
        // 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
        // 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
        // 例子： 
        // dateFormat(new Date(), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
        // dateFormat(new Date(), "yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
        if (!dateTime) {
            return dateTime;
        }
        if (typeof dateTime == 'string' && !isNaN(dateTime)) {
            dateTime = +dateTime;
        }
        dateTime = new Date(dateTime);
        var o = {
            "M+": dateTime.getMonth() + 1, //月份 
            "d+": dateTime.getDate(), //日 
            "h+": dateTime.getHours(), //小时 
            "m+": dateTime.getMinutes(), //分 
            "s+": dateTime.getSeconds(), //秒 
            "q+": Math.floor((dateTime.getMonth() + 3) / 3), //季度 
            "S": dateTime.getMilliseconds() //毫秒 
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (dateTime.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }return fmt;
    },
    getParameters: function getParameters(url, key) {
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var queryString = url.substr(url.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    }
};

exports.default = util;

/***/ }),

/***/ 231:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(232)
)

/* script */
__vue_exports__ = __webpack_require__(233)

/* template */
var __vue_template__ = __webpack_require__(234)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-rooms\\components\\switch.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-a0d6f462"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 232:
/***/ (function(module, exports) {

module.exports = {
  "scroller-bar": {
    "height": 60,
    "width": 104,
    "paddingTop": 36,
    "marginTop": -30
  },
  "scroller-div": {
    "width": 160,
    "flexDirection": "column"
  },
  "container": {
    "backgroundColor": "#5D75F6",
    "borderRadius": 20,
    "width": 80,
    "height": 6
  },
  "container-right": {
    "backgroundColor": "#5D75F6",
    "borderRadius": 2,
    "width": 80,
    "height": 6
  },
  "item-img": {
    "marginTop": -28,
    "marginLeft": 58
  },
  "selected": {
    "backgroundColor": "#5D75F6"
  },
  "unselected": {
    "backgroundColor": "#E5E5E8"
  },
  "grid-option": {
    "justifyContent": "center",
    "borderRadius": 8,
    "borderWidth": 2,
    "paddingLeft": 6,
    "paddingRight": 6
  },
  "text-title": {
    "lines": 2,
    "lineHeight": 30,
    "textOverflow": "ellipsis",
    "textAlign": "center",
    "fontSize": 26
  },
  "image-checked": {
    "position": "absolute",
    "right": 0,
    "bottom": 0,
    "width": 38,
    "height": 34
  }
}

/***/ }),

/***/ 233:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var animation = weex.requireModule('animation');
var modal = weex.requireModule('modal');
exports.default = {
  props: {
    value: {
      type: Number,
      default: -1
    },
    // 是否选中
    iconOn: {
      type: String,
      default: 'assets/img/smart_ic_switch_l@2x.png'
    },
    iconOff: {
      type: String,
      default: 'assets/img/smart_ic_switch_l@2x.png'
    },
    width: {
      type: String,
      default: '48'
    },
    height: {
      type: String,
      default: '48'
    },
    checked: {
      type: Boolean,
      default: false
    }

  },
  computed: {
    icon: function icon() {
      return this.checked ? this.iconOn : this.iconOff;
    }
  },
  data: function data() {
    return {
      selected: "selected",
      unselected: "unselected"
    };
  },

  methods: {
    onchange: function onchange(event) {
      this.checked = !this.checked;
      var switchBar = this.$refs.switchBar;
      if (this.checked) {
        animation.transition(switchBar, {
          styles: {
            transform: 'translateX(-61px)'
          },
          duration: 100, //ms
          timingFunction: 'linear',
          delay: 0 //ms
        }, function () {
          //modal.toast({ message: 'animation finished.' })
        });
      } else {
        animation.transition(switchBar, {
          styles: {
            transform: 'translateX(0px)'
          },
          duration: 100, //ms
          timingFunction: 'linear',
          delay: 0 //ms
        }, function () {
          //modal.toast({ message: 'animation finished.' })
        });
      }

      this.$emit('change', { value: this.checked });
    }
  },
  mounted: function mounted() {
    this.onchange();
  }
};

/***/ }),

/***/ 234:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["scroller-bar"],
    attrs: {
      "offsetAccuracy": "50",
      "showScrollbar": "false"
    },
    on: {
      "click": _vm.onchange
    }
  }, [_c('div', {
    ref: "switchBar",
    staticClass: ["scroller-div"],
    on: {
      "click": _vm.onchange
    }
  }, [_vm._m(0), _c('div', [_c('image', {
    ref: "mysecond",
    staticClass: ["item-img"],
    style: {
      'width': _vm.width,
      'height': _vm.height
    },
    attrs: {
      "src": _vm.icon
    }
  })])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticStyle: {
      flexDirection: "row"
    }
  }, [_c('div', {
    staticClass: ["container", "selected"]
  }), _c('div', {
    staticClass: ["container-right", "unselected"]
  })])
}]}
module.exports.render._withStripped = true

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(4)
)

/* script */
__vue_exports__ = __webpack_require__(5)

/* template */
var __vue_template__ = __webpack_require__(6)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-component\\header.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-14800ea3"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 4:
/***/ (function(module, exports) {

module.exports = {
  "box": {
    "width": 750,
    "height": 88,
    "display": "inline-flex",
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "header": {
    "height": 88,
    "backgroundColor": "#0e90ff"
  },
  "immersion": {
    "paddingTop": 40,
    "height": 128
  },
  "header-left-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "paddingLeft": 32
  },
  "header-right-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "paddingLeft": 12
  },
  "header-left-image": {
    "height": 44,
    "width": 24
  },
  "header-right-image": {
    "height": 44,
    "width": 44
  }
}

/***/ }),

/***/ 43:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(56)
)

/* script */
__vue_exports__ = __webpack_require__(57)

/* template */
var __vue_template__ = __webpack_require__(58)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-component\\overlay.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-1f4ec6aa"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(53)
)

/* script */
__vue_exports__ = __webpack_require__(54)

/* template */
var __vue_template__ = __webpack_require__(55)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-component\\cell.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-6a4e2a78"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _nativeService = __webpack_require__(0);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        title: {
            type: String,
            default: ''
        },
        bgColor: {
            type: String,
            default: '#0E90FF'
        },
        fontSize: {
            type: String,
            default: '36'
        },
        titleText: {
            type: String,
            default: '#fff'
        },
        isImmersion: {
            type: Boolean,
            default: false
        },
        leftImg: {
            type: String,
            default: '../img/header/tab_back.png'
        },
        rightImg: {
            type: String,
            default: '../img/header/tab_seting.png'
        },
        showLeftImg: {
            type: Boolean,
            default: true
        },
        showRightImg: {
            type: Boolean,
            default: false
        }
    },
    data: function data() {
        return {};
    },

    methods: {
        leftImgClick: function leftImgClick() {
            if (!this.showLeftImg) {
                return;
            }
            this.$emit('leftImgClick');
        },
        rightImgClick: function rightImgClick() {
            if (!this.showRightImg) {
                return;
            }
            this.$emit('rightImgClick');
        },
        headerClick: function headerClick() {
            this.$emit('headerClick');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 53:
/***/ (function(module, exports) {

module.exports = {
  "midea-cell": {
    "height": 108,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 24,
    "paddingRight": 24,
    "backgroundColor": "#ffffff"
  },
  "active-cell": {
    "backgroundColor:active": "#f5f5f5"
  },
  "cell-margin": {
    "marginBottom": 24
  },
  "cell-title": {
    "flex": 1
  },
  "cell-indent": {
    "paddingBottom": 30,
    "paddingTop": 30
  },
  "has-desc": {
    "paddingBottom": 18,
    "paddingTop": 18
  },
  "cell-top-border": {
    "borderTopColor": "#e2e2e2",
    "borderTopWidth": 1
  },
  "cell-bottom-border": {
    "borderBottomColor": "#e2e2e2",
    "borderBottomWidth": 1
  },
  "cell-label-text": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text": {
    "fontSize": 24,
    "color": "#999999"
  },
  "cell-arrow-icon": {
    "width": 12,
    "height": 24,
    "position": "absolute",
    "right": 24
  },
  "cell-content": {
    "color": "#333333",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "item-img": {
    "width": 80,
    "height": 80,
    "marginRight": 24
  }
}

/***/ }),

/***/ 54:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _util = __webpack_require__(14);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var icon = __webpack_require__(15);

module.exports = {
  props: {
    height: {
      type: String,
      default: '100'
    },
    label: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    desc: {
      type: String,
      default: ''
    },
    rightText: {
      type: String,
      default: ''
    },
    clickActivied: {
      type: Boolean,
      default: false
    },
    hasTopBorder: {
      type: Boolean,
      default: false
    },
    hasMargin: {
      type: Boolean,
      default: false
    },
    hasBottomBorder: {
      type: Boolean,
      default: true
    },
    hasArrow: {
      type: Boolean,
      default: false
    },
    hasVerticalIndent: {
      type: Boolean,
      default: true
    },
    cellStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    itemImg: {
      type: String,
      default: ''
    }
  },
  computed: {
    outputCellStyle: function outputCellStyle() {
      var height = this.height,
          cellStyle = this.cellStyle;
      //return util.extend({"height":height+"px"},cellStyle);

      return _extends({ "height": height + "px" }, cellStyle);
    }
  },
  data: function data() {
    return {
      //arrowIcon: icon.arrowIcon
      arrowIcon: "./img/arrow_right.png"
    };
  },
  methods: {
    cellClicked: function cellClicked(e) {

      this.$emit('mideaCellClick', { e: e });
    }
  }
};

/***/ }),

/***/ 55:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['midea-cell', _vm.clickActivied && 'active-cell', _vm.hasTopBorder && 'cell-top-border', _vm.hasBottomBorder && 'cell-bottom-border', _vm.hasMargin && 'cell-margin', _vm.hasVerticalIndent && 'cell-indent', _vm.desc && 'has-desc'],
    style: _vm.outputCellStyle,
    on: {
      "click": _vm.cellClicked
    }
  }, [_vm._t("itemImg", [(_vm.itemImg && _vm.itemImg != '') ? _c('image', {
    staticClass: ["item-img"],
    attrs: {
      "src": _vm.itemImg
    }
  }) : _vm._e()]), _vm._t("label", [(_vm.label) ? _c('div', [_c('text', {
    staticClass: ["cell-label-text"]
  }, [_vm._v(_vm._s(_vm.label))])]) : _vm._e()]), _c('div', {
    staticClass: ["cell-title"]
  }, [_vm._t("title", [_c('text', {
    staticClass: ["cell-content"]
  }, [_vm._v(_vm._s(_vm.title))]), (_vm.desc) ? _c('text', {
    staticClass: ["cell-desc-text"]
  }, [_vm._v(_vm._s(_vm.desc))]) : _vm._e()])], 2), _vm._t("value"), _vm._t("text"), _vm._t("rightText", [(_vm.rightText) ? _c('div', {
    style: {
      paddingRight: _vm.hasArrow ? '24px' : '0px'
    }
  }, [_c('text', {
    staticClass: ["right-text"]
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e()]), (_vm.hasArrow) ? _c('image', {
    staticClass: ["cell-arrow-icon"],
    style: {
      top: ((_vm.height - 24) / 2) + 'px'
    },
    attrs: {
      "src": _vm.arrowIcon
    }
  }) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 56:
/***/ (function(module, exports) {

module.exports = {
  "midea-overlay": {
    "width": 750,
    "position": "fixed",
    "left": 0,
    "top": 0,
    "bottom": 0,
    "right": 0
  }
}

/***/ }),

/***/ 57:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var animation = weex.requireModule('animation');
module.exports = {
  props: {
    show: {
      type: Boolean,
      default: true
    },
    hasAnimation: {
      type: Boolean,
      default: true
    },
    duration: {
      type: [Number, String],
      default: 300
    },
    timingFunction: {
      type: Array,
      default: function _default() {
        return ['ease-in', 'ease-out'];
      }
    },
    opacity: {
      type: [Number, String],
      default: 0.6
    },
    canAutoClose: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    overlayStyle: function overlayStyle() {
      return {
        opacity: this.hasAnimation ? 0 : 1,
        backgroundColor: 'rgba(0, 0, 0,' + this.opacity + ')'
      };
    },
    shouldShow: function shouldShow() {
      var _this = this;

      var show = this.show,
          hasAnimation = this.hasAnimation;

      hasAnimation && setTimeout(function () {
        _this.appearOverlay(show);
      }, 50);
      return show;
    }
  },
  methods: {
    overlayClicked: function overlayClicked(e) {
      this.canAutoClose ? this.appearOverlay(false) : this.$emit('mideaOverlayBodyClicked', {});
    },
    appearOverlay: function appearOverlay(bool) {
      var _this2 = this;

      var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.duration;
      var hasAnimation = this.hasAnimation,
          timingFunction = this.timingFunction,
          canAutoClose = this.canAutoClose;

      var needEmit = !bool && canAutoClose;
      needEmit && this.$emit('mideaOverlayBodyClicked', {});
      var overlayEl = this.$refs['midea-overlay'];
      if (hasAnimation && overlayEl) {
        animation.transition(overlayEl, {
          styles: {
            opacity: bool ? 1 : 0
          },
          duration: duration,
          timingFunction: timingFunction[bool ? 0 : 1],
          delay: 0
        }, function () {
          needEmit && _this2.$emit('mideaOverlayBodyClicked', {});
        });
      } else {
        needEmit && this.$emit('mideaOverlayBodyClicked', {});
      }
    }
  }
};

/***/ }),

/***/ 58:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [(_vm.show) ? _c('div', {
    ref: "midea-overlay",
    staticClass: ["midea-overlay"],
    style: _vm.overlayStyle,
    attrs: {
      "hack": _vm.shouldShow
    },
    on: {
      "click": _vm.overlayClicked
    }
  }) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 6:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"],
    staticStyle: {
      width: "750px"
    }
  }, [_c('div', {
    staticClass: ["box"],
    class: [_vm.isImmersion && 'immersion'],
    style: {
      backgroundColor: _vm.bgColor
    }
  }, [_c('div', {
    staticClass: ["header-left-image-wrapper"],
    on: {
      "click": _vm.leftImgClick
    }
  }, [(_vm.showLeftImg) ? _c('image', {
    staticClass: ["header-left-image"],
    attrs: {
      "src": _vm.leftImg
    }
  }) : _vm._e()]), _c('div', {
    on: {
      "click": _vm.headerClick
    }
  }, [_c('text', {
    style: {
      color: _vm.titleText,
      fontSize: _vm.fontSize + 'px'
    }
  }, [_vm._v(_vm._s(_vm.title))])]), _c('div', {
    staticClass: ["header-right-image-wrapper"],
    on: {
      "click": _vm.rightImgClick
    }
  }, [_vm._t("rightContent", [(_vm.showRightImg) ? _c('image', {
    staticClass: ["header-right-image"],
    attrs: {
      "src": _vm.rightImg
    }
  }) : _vm._e()])], 2), _vm._t("customerContent")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(65)
)

/* script */
__vue_exports__ = __webpack_require__(66)

/* template */
var __vue_template__ = __webpack_require__(67)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-component\\popup.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5c326d86"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 65:
/***/ (function(module, exports) {

module.exports = {
  "midea-popup": {
    "position": "fixed",
    "width": 750
  },
  "top": {
    "left": 0,
    "right": 0
  },
  "bottom": {
    "left": 0,
    "right": 0
  },
  "left": {
    "bottom": 0,
    "top": 0
  },
  "right": {
    "bottom": 0,
    "top": 0
  }
}

/***/ }),

/***/ 66:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _overlay = __webpack_require__(43);

var _overlay2 = _interopRequireDefault(_overlay);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var animation = weex.requireModule('animation');
var platform = weex.config.env.platform;

var isWeb = (typeof window === 'undefined' ? 'undefined' : _typeof(window)) === 'object' && platform.toLowerCase() === 'web';

module.exports = {
  components: { mideaOverlay: _overlay2.default },
  props: {
    show: {
      type: Boolean,
      default: false
    },
    pos: {
      type: String,
      default: 'bottom'
    },
    popupColor: {
      type: String,
      default: '#FFFFFF'
    },
    overlayCfg: {
      type: Object,
      default: function _default() {
        return {
          hasAnimation: true,
          timingFunction: ['ease-in', 'ease-out'],
          duration: 300,
          opacity: 0.6
        };
      }
    },
    height: {
      type: [Number, String],
      default: 840
    },
    standOut: {
      type: [Number, String],
      default: 0
    },
    width: {
      type: [Number, String],
      default: 750
    },
    animation: {
      type: Object,
      default: function _default() {
        return {
          timingFunction: 'ease-in'
        };
      }
    }
  },
  data: function data() {
    return {
      haveOverlay: true,
      isOverShow: true
    };
  },
  computed: {
    isNeedShow: function isNeedShow() {
      var _this = this;

      setTimeout(function () {
        _this.appearPopup(_this.show);
      }, 50);
      return this.show;
    },
    _height: function _height() {
      this.appearPopup(this.show, 150);
      return this.height;
    },
    transformValue: function transformValue() {
      return this.getTransform(this.pos, this.width, this.height, true);
    },
    padStyle: function padStyle() {
      var pos = this.pos,
          width = this.width,
          height = this.height,
          popupColor = this.popupColor;

      var style = {
        width: width + 'px',
        backgroundColor: popupColor
      };
      pos === 'top' && (style = _extends({}, style, {
        top: -height + 'px',
        height: height + 'px'
      }));
      pos === 'bottom' && (style = _extends({}, style, {
        bottom: -height + 'px',
        height: height + 'px'
      }));
      pos === 'left' && (style = _extends({}, style, {
        left: -width + 'px'
      }));
      pos === 'right' && (style = _extends({}, style, {
        right: -width + 'px'
      }));
      return style;
    }
  },
  methods: {
    handleTouchEnd: function handleTouchEnd(e) {
      // 在支付宝上面有点击穿透问题
      var platform = weex.config.env.platform;

      platform === 'Web' && e.preventDefault && e.preventDefault();
    },
    hide: function hide() {
      this.appearPopup(false);
      this.$refs.overlay.appearOverlay(false);
    },
    mideaOverlayBodyClicking: function mideaOverlayBodyClicking() {
      this.isShow && this.appearPopup(false);
    },
    appearPopup: function appearPopup(bool) {
      var _this2 = this;

      var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;

      this.isShow = bool;
      var popupEl = this.$refs['midea-popup'];
      if (!popupEl) {
        return;
      }
      animation.transition(popupEl, _extends({
        styles: {
          transform: this.getTransform(this.pos, this.width, this.height, !bool)
        },
        duration: duration,
        delay: 0
      }, this.animation), function () {
        if (!bool) {
          _this2.$emit('mideaPopupOverlayClicked', { pos: _this2.pos });
        }
      });
    },
    getTransform: function getTransform(pos, width, height, bool) {
      var _size = pos === 'top' || pos === 'bottom' ? height : width;
      var _transform = void 0;
      if (isWeb) {
        _size -= this.standOut;
      }
      bool && (_size = 0);
      switch (pos) {
        case 'top':
          _transform = 'translateY(' + _size + 'px)';
          break;
        case 'bottom':
          _transform = 'translateY(-' + _size + 'px)';
          break;
        case 'left':
          _transform = 'translateX(' + _size + 'px)';
          break;
        case 'right':
          _transform = 'translateX(-' + _size + 'px)';
          break;
      }
      return _transform;
    }
  }
};

/***/ }),

/***/ 67:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    on: {
      "touchend": _vm.handleTouchEnd
    }
  }, [(_vm.show) ? _c('midea-overlay', _vm._b({
    ref: "overlay",
    attrs: {
      "show": _vm.haveOverlay && _vm.isOverShow
    },
    on: {
      "mideaOverlayBodyClicked": _vm.mideaOverlayBodyClicking
    }
  }, 'midea-overlay', _vm.overlayCfg, false)) : _vm._e()], 1), (_vm.show) ? _c('div', {
    ref: "midea-popup",
    class: ['midea-popup', _vm.pos],
    style: _vm.padStyle,
    attrs: {
      "height": _vm._height,
      "hack": _vm.isNeedShow
    },
    on: {
      "click": function () {}
    }
  }, [_vm._t("default")], 2) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 68:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _nativeService = __webpack_require__(0);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _debugUtil = __webpack_require__(1);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _header = __webpack_require__(3);

var _header2 = _interopRequireDefault(_header);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var appDataTemplate = {};

var bundleUrl = weex.config.bundleUrl;
var match = /.*\/(T0x.*)\//g.exec(bundleUrl);
var plugin_name = match ? match[1] : 'common'; //appConfig.plugin_name
var srcFileName = bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'));

var globalEvent = weex.requireModule('globalEvent');
var storage = weex.requireModule('storage');
var stream = weex.requireModule('stream');

var appDataChannel = new BroadcastChannel(plugin_name + 'appData');
var pushDataChannel = new BroadcastChannel(plugin_name + 'pushData');
var bridgeModule = weex.requireModule('bridgeModule');

exports.default = {
    components: {
        mideaHeader: _header2.default
    },
    data: function data() {
        return {
            title: '',
            isIos: weex.config.env.platform == 'iOS' ? true : false,
            srcFileName: srcFileName,
            pluginVersion: '1.0.0',
            pluginName: plugin_name,
            isMixinCreated: true,
            isNavigating: false,
            appDataKey: plugin_name + 'appData',
            appDataChannel: appDataChannel,
            pushKey: 'receiveMessage',
            pushDataChannel: pushDataChannel,
            appData: appDataTemplate
        };
    },
    computed: {
        pageHeight: function pageHeight() {
            return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight;
        },

        isipx: function isipx() {
            //是否是iphoneX
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6');
        }
    },
    methods: {
        viewappear: function viewappear() {},
        viewdisappear: function viewdisappear() {
            _debugUtil2.default.resetDebugLog();
        },

        getParameterByName: function getParameterByName(name) {
            var url = this.$getConfig().bundleUrl;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        },
        goTo: function goTo(pageName) {
            var _this = this;

            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var params = arguments[2];

            if (!this.isNavigating) {
                this.isNavigating = true;
                // 离开时同步全局应用数据
                _nativeService2.default.setItem(this.appDataKey, this.appData, function () {
                    //跳转页面
                    var path = pageName + ".js";
                    if (params) {
                        path += '?' + Object.keys(params).map(function (k) {
                            return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
                        }).join('&');
                    }
                    options.viewTag = pageName;
                    _nativeService2.default.goTo(path, options);
                    setTimeout(function () {
                        _this.isNavigating = false;
                    }, 500);
                });
            }
        },
        back: function back() {
            //返回上一页
            _nativeService2.default.goBack();
        },
        exit: function exit() {
            _nativeService2.default.backToNative();
        },
        getAppData: function getAppData() {
            var _this2 = this;

            //获取全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.getItem(_this2.appDataKey, function (resp) {
                    var data = void 0;
                    if (resp.result == 'success') {
                        data = resp.data;
                        if (typeof data == 'string') {
                            try {
                                data = JSON.parse(data);
                            } catch (error) {}
                        }
                    }
                    if (!data) {
                        data = _this2.appData;
                    }
                    resolve(data);
                });
            });
        },
        updateAppData: function updateAppData(data) {
            //更新全局应用数据
            this.appData = Object.assign(this.appData, data);
            appDataChannel.postMessage(this.appData);
        },
        resetAppData: function resetAppData() {
            var _this3 = this;

            //重置全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.removeItem(_this3.appDataKey, function (resp) {
                    _this3.appData = JSON.parse(JSON.stringify(appDataTemplate));
                    appDataChannel.postMessage(_this3.appData);
                    resolve();
                });
            });
        },
        handleNotification: function handleNotification(data) {
            //处理推送消息
            _debugUtil2.default.debugLog(srcFileName, this.pushKey, data);
        },
        uuid: function uuid() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
            });
            return uuid;
        },
        generateReqBody: function generateReqBody(reqBody) {
            //生成weex stream 请求的reqBody，String格式
            reqBody = Object.assign({
                reqId: this.uuid(),
                appId: '1000',
                stamp: +new Date()
            }, reqBody);

            return JSON.stringify(reqBody);
        },
        webRequest: function webRequest(reqUrl, reqParams) {
            var _this4 = this;

            var isShowLoading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

            return new Promise(function (resolve, reject) {
                //     let reqBody = this.generateReqBody(reqParams)
                //     stream.fetch({
                //         method: 'post',
                //         url: reqUrl,
                //         mode: 'cors',
                //         headers: {
                //             'Content-Type': 'application/json;charset=utf-8',
                //         },
                //         type: 'json',
                //         body: reqBody
                //     }, (rtnData) => {
                //         if (rtnData.ok) {
                //             resolve(rtnData.data)
                //         } else {
                //             reject(rtnData)
                //         }
                //     })
                var requestOption = {
                    method: "POST",
                    isShowLoading: isShowLoading
                };
                var requestParam = {
                    method: requestOption.method,
                    headers: {
                        "Content-Type": "application/json;charset=utf-8"
                    },
                    data: _this4.generateReqBody(reqParams)
                };
                _nativeService2.default.isDummy = false;
                _nativeService2.default.sendCentralCloundRequest(reqUrl, requestParam, requestOption).then(function (resp) {
                    resolve(resp);
                }).catch(function (error) {
                    reject(error);
                });
            });
        },
        reload: function reload() {
            bridgeModule.reload({}, function (result) {}, function (err) {});
        }
    },
    created: function created() {
        var _this5 = this;

        console.log("created");
        //若isMixinCreated为false, 则不继承
        if (!this.isMixinCreated) return;

        //Debug Log相关信息
        _debugUtil2.default.isEnableDebugInfo = false; //开启关闭debuglog功能
        _debugUtil2.default.debugLog("@@@@@@ " + this.title + "(" + plugin_name + "-" + srcFileName + ") @@@@@@");

        //监听全局推送(native->weex)
        globalEvent.addEventListener(this.pushKey, function (data) {
            _debugUtil2.default.debugLog(_this5.title + "=>" + _this5.pushKey + ": " + data);
            //触发本页面处理事件
            _this5.handleNotification(data || {});
            //触发其他页面处理事件
            pushDataChannel.postMessage(data);
        });
        //监听全局推送通信渠道(weex->weex)
        pushDataChannel.onmessage = function (event) {
            _this5.handleNotification(event.data || {});
        };

        //监听全局应用数据通信渠道(weex->weex)
        appDataChannel.onmessage = function (event) {
            _this5.appData = event.data || {};
        };
        //页面创建时获取全局应用数据
        this.getAppData().then(function (data) {
            _this5.appData = data || {};
        });
    }
};

/***/ }),

/***/ 69:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(70)
)

/* script */
__vue_exports__ = __webpack_require__(71)

/* template */
var __vue_template__ = __webpack_require__(72)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-rooms\\components\\list.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-45b05ef9"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 70:
/***/ (function(module, exports) {

module.exports = {}

/***/ }),

/***/ 71:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        idx: {
            type: Number,
            default: 0
        },
        hasWrapBorder: {
            type: Boolean,
            default: false
        },
        leftMargin: {
            type: String,
            default: '25px'
        },
        height: {
            type: String,
            default: '80px'
        },
        renderData: {
            type: Array,
            default: function _default() {
                return [1, 2];
            }
        }
    },
    computed: {
        wrapBorderStatus: function wrapBorderStatus() {
            var tmp = '';
            if (this.idx == 0) {
                if (this.hasWrapBorder) {
                    tmp = 'border-top-active';
                } else {
                    tmp = 'border-top-off';
                }
            }
            return tmp;
        },
        itemStyle: function itemStyle() {
            var tmp = {};
            if (this.hasWrapBorder) {
                tmp.borderBottomWidth = '2px';
                tmp.borderBottomStyle = 'solid';
                tmp.borderBottomColor = '#e5e5e5';
            } else {
                tmp.borderTopWidth = '2px';
                tmp.borderTopStyle = 'solid';
                tmp.borderTopColor = '#e5e5e5';
            }
            if (this.idx == 0) {
                if (this.hasWrapBorder) {
                    tmp.borderTopWidth = '2px';
                    tmp.borderTopStyle = 'solid';
                    tmp.borderTopColor = '#e5e5e5';
                } else {
                    tmp.borderTopColor = 'transparent';
                }
            }
            tmp.marginLeft = this.leftMargin;
            return tmp;
        }
    },
    data: function data() {
        return {};
    },

    methods: {},
    created: function created() {}
};

/***/ }),

/***/ 72:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: ["item"],
    style: _vm.itemStyle
  }, [_vm._t("default")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 830:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _setDevice = __webpack_require__(831);

var _setDevice2 = _interopRequireDefault(_setDevice);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new Vue({
  el: '#root',
  render: function render(h) {
    return h(_setDevice2.default);
  }
}); // 自动生成的入口文件

/***/ }),

/***/ 831:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(832)
)

/* script */
__vue_exports__ = __webpack_require__(833)

/* template */
var __vue_template__ = __webpack_require__(834)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\code\\midea-weex-template\\src\\midea-rooms\\setDevice.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-9d776326"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 832:
/***/ (function(module, exports) {

module.exports = {
  "row-sb": {
    "flexDirection": "row",
    "alignItems": "center",
    "justifyContent": "space-between"
  },
  "row-e": {
    "flexDirection": "row",
    "alignItems": "center",
    "justifyContent": "flex-end"
  },
  "wrap": {
    "backgroundColor": "#f2f2f2"
  },
  "font-grey": {
    "color": "#666666"
  },
  "hd": {
    "backgroundColor": "#ffffff",
    "width": 750,
    "height": 88,
    "paddingLeft": 30,
    "paddingRight": 30
  },
  "hd-text": {
    "fontSize": 32
  },
  "content": {
    "paddingTop": 50
  },
  "sub-hd": {
    "color": "#666666",
    "fontSize": 28,
    "marginLeft": 30,
    "marginBottom": 18
  },
  "floor": {
    "marginLeft": 25,
    "paddingTop": 25,
    "paddingBottom": 25,
    "paddingRight": 25,
    "borderTopWidth": 2,
    "borderTopStyle": "solid",
    "borderTopColor": "#e5e5e5"
  },
  "no-border": {
    "borderTopColor": "rgba(0,0,0,0)"
  },
  "ability-list": {
    "backgroundColor": "#ffffff"
  },
  "property-text": {
    "color": "#666666",
    "fontSize": 30
  },
  "icon": {
    "width": 12,
    "height": 24,
    "marginLeft": 20
  },
  "pop-text": {
    "fontSize": 30,
    "color": "#007AFF",
    "paddingTop": 25,
    "paddingRight": 25,
    "paddingBottom": 25,
    "paddingLeft": 25
  },
  "pop-item": {
    "paddingTop": 22,
    "paddingRight": 22,
    "paddingBottom": 22,
    "paddingLeft": 22,
    "fontSize": 30,
    "color": "#777777",
    "textAlign": "center",
    "width": 750
  },
  "pop-item-active": {
    "color": "#333333"
  }
}

/***/ }),

/***/ 833:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _config = __webpack_require__(88);

var _base = __webpack_require__(68);

var _base2 = _interopRequireDefault(_base);

var _nativeService = __webpack_require__(0);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _cell = __webpack_require__(44);

var _cell2 = _interopRequireDefault(_cell);

var _popup = __webpack_require__(61);

var _popup2 = _interopRequireDefault(_popup);

var _switch = __webpack_require__(231);

var _switch2 = _interopRequireDefault(_switch);

var _list = __webpack_require__(69);

var _list2 = _interopRequireDefault(_list);

var _scrollPicker = __webpack_require__(170);

var _scrollPicker2 = _interopRequireDefault(_scrollPicker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var channelSetDevice = new BroadcastChannel('autoBroadcast');

exports.default = {
    components: { switchBar: _switch2.default, MideaPopup: _popup2.default, scrollPicker: _scrollPicker2.default },
    mixins: [_base2.default],
    data: function data() {
        return {
            icon: {
                more: 'assets/img/more.png'
            },
            from: '',
            deviceName: '',
            actions: {},
            userDevice: [],
            deviceTask: {},
            show: {},
            active: {},
            activeKey: {},
            applianceActions: _config.applianceActions,
            autoSupportActions: _config.autoSupportActions[this.sceneType],
            rangeArrays: {
                temperature: [],
                windSpeed: []
            }
        };
    },

    computed: {
        wrapStyle: function wrapStyle() {
            var tmp = {
                height: this.pageHeight + 'px'
            };
            return tmp;
        }
    },
    methods: {
        goBack: function goBack() {
            _nativeService2.default.goBack();
        },
        initData: function initData() {
            this.sceneType = _nativeService2.default.getParameters('sceneType');
            this.deviceType = _nativeService2.default.getParameters('deviceType');
            this.deviceName = decodeURIComponent(_nativeService2.default.getParameters('deviceName'));
            this.deviceId = _nativeService2.default.getParameters('deviceId');
            this.from = _nativeService2.default.getParameters('from');

            if (this.from == 'addAuto') {} else if (this.from == 'editAuto') {
                this.deviceTask = Object.assign({}, this.deviceTask, JSON.parse(decodeURIComponent(_nativeService2.default.getParameters('deviceTask'))));
            }
            var tmpActions = _config.autoSupportActions[this.sceneType][this.deviceType].actions;

            var tmpShow = {};
            var tmpActiveKey = {};
            for (var i in tmpActions) {
                var currentStatus = void 0;
                if (this.from == 'addAuto' || this.from == 'addEdit') {
                    currentStatus = tmpActions[i].default;
                } else if (this.from == 'editAuto') {
                    if (this.deviceTask[tmpActions[i].property]) {
                        currentStatus = this.deviceTask[tmpActions[i].property];
                    } else {
                        currentStatus = tmpActions[i].default;
                    }
                }
                if (tmpActions[i].type == 'range') {
                    tmpActions[i] = Object.assign({}, tmpActions[i], { currentStatus: currentStatus });
                } else {
                    tmpActions[i] = Object.assign({}, tmpActions[i], { currentStatus: currentStatus, currentStatusName: tmpActions[i]['value'][currentStatus] });
                }

                //显示启用按钮状态， 初始化选择项activeKey
                if (tmpActions[i].type == 'switch') {} else if (tmpActions[i].type == 'list') {
                    tmpShow[tmpActions[i].property] = false; //初始化弹窗显示状态为false
                } else if (tmpActions[i].type == 'range') {
                    tmpShow[tmpActions[i].property] = false; //初始化弹窗显示状态为false
                    this.rangeArrays[tmpActions[i].property] = this.generateListArray(tmpActions[i].range.min, tmpActions[i].range.max);
                }
            }

            this.actions = tmpActions;
            this.show = Object.assign({}, this.show, tmpShow);
            this.activeKey = Object.assign({}, this.activeKey, tmpActiveKey);
        },
        switchAction: function switchAction(action, i) {
            var tmp = {
                'on': 'off',
                'off': 'on'
            };
            this.actions[i].currentStatus = tmp[this.actions[i].currentStatus];
        },
        generateListArray: function generateListArray(min, max) {
            var tmp = [];
            var len = max - min + 1;
            for (var i = 0; i < len; i++) {
                tmp[i] = { index: i, value: i + min };
            }
            return tmp;
        },
        showPop: function showPop(property) {
            this.show[property] = true;
        },
        closePop: function closePop(property) {
            this.show[property] = false;
        },
        cancelPop: function cancelPop(property) {
            this.show[property] = false;
        },
        confirmPop: function confirmPop(property) {
            this.show[property] = false;
            for (var x in this.actions) {
                if (this.actions[x].property == property) {
                    this.actions[x].currentStatus = this.active[property];
                }
            }
        },
        setActiveTemperature: function setActiveTemperature(e) {
            this.active.temperature = e.value;
        },
        setActiveWindSpeed: function setActiveWindSpeed(e) {
            this.active.windSpeed = e.value;
        },
        setActiveKey: function setActiveKey(propertyIdx, key) {
            this.actions[propertyIdx].currentStatus = key;
            this.actions[propertyIdx].currentStatusName = this.actions[propertyIdx]['value'][key];
        },
        save: function save() {
            channelSetDevice.postMessage({
                page: 'setDevice',
                applianceCode: this.deviceId,
                actions: this.actions
            });
            this.goBack();
        }
    },
    created: function created() {
        this.initData();
    }
};

/***/ }),

/***/ 834:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrap"],
    style: _vm.wrapStyle
  }, [_c('div', {
    staticClass: ["row-sb", "hd"]
  }, [_c('text', {
    staticClass: ["hd-text", "font-grey"],
    on: {
      "click": _vm.goBack
    }
  }, [_vm._v("取消")]), _c('text', {
    staticClass: ["hd-text"]
  }, [_vm._v(_vm._s(_vm.deviceName))]), _c('text', {
    staticClass: ["hd-text", "font-grey"],
    on: {
      "click": _vm.save
    }
  }, [_vm._v("确定")])]), _c('list', [_c('cell', {
    staticClass: ["content"],
    appendAsTree: true,
    attrs: {
      "append": "tree"
    }
  }, [_c('text', {
    staticClass: ["sub-hd"]
  }, [_vm._v("设置为")]), _vm._l((_vm.actions), function(item, i) {
    return _c('div', {
      staticClass: ["ability-list"]
    }, [_c('div', {
      class: ['row-sb', 'floor', i == '0' ? 'no-border' : '']
    }, [_c('text', [_vm._v(_vm._s(item.propertyName))]), _c('div', [(item.type == 'switch') ? _c('switch-bar', {
      attrs: {
        "checked": item.currentStatus == 'on' ? 1 : 0
      },
      on: {
        "change": function($event) {
          _vm.switchAction(item, i)
        }
      }
    }) : _vm._e(), (item.type == 'list' || item.type == 'range') ? _c('div', {
      staticClass: ["row-e"],
      on: {
        "click": function($event) {
          _vm.showPop(item.property)
        }
      }
    }, [(item.type == 'list') ? _c('text', {
      staticClass: ["property-text"]
    }, [_vm._v(_vm._s(item.currentStatusName))]) : _vm._e(), (item.type == 'range') ? _c('text', {
      staticClass: ["property-text"]
    }, [_vm._v(_vm._s(item.currentStatus))]) : _vm._e(), _c('image', {
      staticClass: ["icon"],
      attrs: {
        "src": _vm.icon.more
      }
    })]) : _vm._e()], 1)])])
  })], 2)]), _vm._l((_vm.actions), function(item, idx) {
    return _c('div', {
      staticClass: ["pop-floor"]
    }, [(item.type == 'list' || item.type == 'range') ? _c('midea-popup', {
      attrs: {
        "show": _vm.show[item.property],
        "height": 600
      },
      on: {
        "mideaPopupOverlayClicked": function($event) {
          _vm.closePop(item.property)
        }
      }
    }, [_c('div', {
      staticClass: ["row-sb", "pop-hd"]
    }, [_c('text', {
      staticClass: ["pop-text"],
      on: {
        "click": function($event) {
          _vm.closePop(item.property)
        }
      }
    }, [_vm._v("取消")]), _c('text', {
      staticClass: ["pop-text"],
      on: {
        "click": function($event) {
          _vm.confirmPop(item.property)
        }
      }
    }, [_vm._v("确定")])]), (item.type == 'list') ? _c('scroller', _vm._l((item.value), function(value, key) {
      return _c('text', {
        class: ['pop-item', item.currentStatus == key ? 'pop-item-active' : ''],
        on: {
          "click": function($event) {
            _vm.setActiveKey(idx, key)
          }
        }
      }, [_vm._v(_vm._s(value))])
    })) : _vm._e(), (item.type == 'range') ? _c('div', [(item.property == 'temperature') ? _c('scroll-picker', {
      attrs: {
        "listArray": _vm.rangeArrays[item.property]
      },
      on: {
        "onChange": _vm.setActiveTemperature
      }
    }) : _vm._e(), (item.property == 'wind_speed') ? _c('scroll-picker', {
      attrs: {
        "listArray": _vm.rangeArrays[item.property]
      },
      on: {
        "onChange": _vm.setActiveWindSpeed
      }
    }) : _vm._e()], 1) : _vm._e()]) : _vm._e()], 1)
  })], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 88:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var env = 'sit';
// const env = 'dev'
var domains = {
    'sit': '',
    'dev': 'http://iot-dev.smartmidea.net'
};
var domain = exports.domain = domains[env];
var url = exports.url = {
    scene: {
        applianceAdd: domain + '/v1/scene/appliance/add',
        applianceDelete: domain + '/v1/scene/appliance/delete',
        list: domain + '/v1/scene/list',
        detail: domain + '/v1/scene/detail',
        supportList: domain + '/v1/scene/support/type/list',
        modelSet: domain + '/v1/scene/model/set',
        modelExecute: domain + '/v1/scene/model/execute',
        modelStatus: domain + '/v1/scene/model/status/get',
        optimize: domain + '/v1/scene/optimize',
        optimizeStatus: domain + '/v1/scene/optimize/status/get',
        record: domain + '/v1/scene/record/list',
        recordDelete: domain + '/v1/scene/record/delete',
        washerConsumption: domain + '/v1/scene/washerConsumption'
    },
    auto: {
        list: domain + '/v1/scene/auto/list',
        add: domain + '/v1/scene/auto/add',
        detail: domain + '/v1/scene/auto/detail',
        update: domain + '/v1/scene/auto/update',
        delete: domain + '/v1/scene/auto/delete',
        execute: domain + '/v1/scene/auto/execute',
        status: domain + '/v1/scene/auto/status/get',
        recordUpload: domain + '/v1/scene/auto/record/upload',
        record: domain + '/v1/scene/auto/record/list',
        recordDelete: domain + '/v1/scene/auto/record/delete',
        ApplianceAction: domain + '/v1/scene/auto/action/list'
    }
};

var applianceActions = exports.applianceActions = {
    "0xAC": {
        "name": "空调",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            },
            "temperature": {
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }
        }
    },
    "0xE2": {
        "name": "热水器",
        "img": "assets/img/0xE2.png",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "temperature": {
                "type": "range",
                "range": {
                    "max": 75,
                    "min": 30
                },
                "default": 65
            }
        }
    },
    "0xFC": {
        "name": "空气净化器",
        "img": "assets/img/0xFC.png",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "auto": "自动",
                    "manual": "手动",
                    "sleep": "睡眠",
                    "fast": "急速"
                },
                "default": "auto"
            },
            "wind_speed": {
                "type": "range",
                "range": {
                    "max": 0,
                    "min": 101
                },
                "default": 101
            }
        }
    },
    "0xB8": {
        "name": "吸尘器",
        "actions": {
            "work_status": {
                "type": "list",
                "value": {
                    "work": "启动",
                    "stop": "停止",
                    "charge": "回充"
                },
                "default": "stop"
            },
            "work_mode": {
                "type": "list",
                "value": {
                    "random": "随机模式",
                    "arc": "弓形模式",
                    "edge": "沿边模式",
                    "emphases": "重点模式",
                    "screw": "螺旋模式",
                    "auto": "自动模式"
                },
                "default": "auto"
            }
        }
    },
    "0xFB": {
        "name": "电暖器",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "temperature": {
                "type": "range",
                "range": {
                    "max": 50,
                    "min": -40
                },
                "default": 27
            }
        }
    },
    "0xB6": {
        "name": "抽油烟机",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "gear": {
                "type": "list",
                "value": {
                    "1": "1档",
                    "2": "2档",
                    "3": "3档",
                    "4": "4档"
                },
                "default": "1"
            }
        }
    },
    "0xE1": {
        "name": "洗碗机",
        "actions": {
            "work_status": {
                "type": "list",
                "value": {
                    "soft_gear": "软水档位设置中",
                    "error": "错误",
                    "order": "预约",
                    "work": "开始工作",
                    "cancel": "取消工作",
                    "power_off": "关机",
                    "power_on": "开机"
                },
                "default": "power_off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "self_define": "自定义",
                    "fast_wash": "快速洗",
                    "glass_wash": "玻璃洗",
                    "eco_wash": "节能洗/经济洗",
                    "standard_wash": "及时洗/标准洗",
                    "strong_wash": "强力洗",
                    "auto_wash": "自动洗/智能洗"
                },
                "default": "auto_wash"
            }
        }
    },
    "0xFA": {
        "name": "风扇",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "normal": "正常风",
                    "natural": "自然风",
                    "sleep": "睡眠风",
                    "comfort": "舒适风",
                    "feel": "人感",
                    "baby": "宝宝风",
                    "mute": "静音风"
                },
                "default": "normal"
            }
        }
    },
    "0xE3": {
        "name": "燃热水器",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "temperature": {
                "type": "range",
                "range": {
                    "max": 65,
                    "min": 35
                },
                "default": 65
            }
        }
    },
    "0xFD": {
        "name": "加湿器",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "wind_speed": {
                "type": "list",
                "value": {
                    "low": "低风",
                    "middle": "中风",
                    "high": "高风",
                    "auto": "自动"
                },
                "default": "auto"
            }
        }
    },
    "0xA1": {
        "name": "除湿器",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "set": "设定除湿",
                    "continuity": "连续除湿",
                    "auto": "自动除湿",
                    "dry_clothes": "干衣模式",
                    "dry_shoes": "干鞋模式"
                },
                "default": "auto"
            }
        }
    },
    "0xCC": {
        "name": "中央空调",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            },
            "mode": {
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            },
            "temperature": {
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }
        }
    },
    "0x10": {
        "name": "插座",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }
        }
    },
    "0x13": {
        "name": "WiFi吸顶灯",
        "actions": {
            "power": {
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }
        }
    }

    /*
    '2': ["0xAC", "0xE2", "0xFC", "0xB8", "0xFB", "0xB6", "0xE1", "0xFA", "0xE3", "0xFD", "0xA1", "0x10", "0xCC", "0x13"],
    '3': ["0xAC", "0xE2", "0xFC", "0xB8", "0xFB", "0xB6", "0xE1", "0xFA", "0xE3", "0xFD", "0xA1", "0x10", "0xCC", "0x13"],
    '4': ["0xAC", "0xE2", "0xFC", "0xB8", "0xFB", "0xB6", "0xE1", "0xFA", "0xE3", "0xFD", "0xA1", "0x10", "0xCC", "0x13"],
    '6': ["0xAC", "0xE2", "0xFC", "0xFB", "0xFA", "0xE3", "0xFD", "0xA1", "0x10", "0xCC"]
    */
};var autoSupportActions = exports.autoSupportActions = {
    '2': {
        "0xAC": {
            "name": "空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xCC": {
            "name": "中央空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xE1": {
            "name": "洗碗机",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "soft_gear": "软水档位设置中",
                    "error": "错误",
                    "order": "预约",
                    "work": "开始工作",
                    "cancel": "取消工作",
                    "power_off": "关机",
                    "power_on": "开机"
                },
                "default": "power_off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "self_define": "自定义",
                    "fast_wash": "快速洗",
                    "glass_wash": "玻璃洗",
                    "eco_wash": "节能洗/经济洗",
                    "standard_wash": "及时洗/标准洗",
                    "strong_wash": "强力洗",
                    "auto_wash": "自动洗/智能洗"
                },
                "default": "auto_wash"
            }]
        },
        "0xE2": {
            "name": "热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 75,
                    "min": 30
                },
                "default": 65
            }]
        },
        "0xE3": {
            "name": "燃热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 65,
                    "min": 35
                },
                "default": 65
            }]
        },
        "0xFA": {
            "name": "风扇",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "normal": "正常风",
                    "natural": "自然风",
                    "sleep": "睡眠风",
                    "comfort": "舒适风",
                    "feel": "人感",
                    "baby": "宝宝风",
                    "mute": "静音风"
                },
                "default": "normal"
            }]
        },
        "0xFB": {
            "name": "电暖器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 50,
                    "min": -40
                },
                "default": 27
            }]
        },
        "0xFC": {
            "name": "空气净化器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "value": {
                    "auto": "自动",
                    "manual": "手动",
                    "sleep": "睡眠",
                    "fast": "急速"
                }
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "range",
                "range": {
                    "max": 0,
                    "min": 101
                },
                "default": 101
            }]
        },
        "0xFD": {
            "name": "加湿器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "list",
                "value": {
                    "low": "低风",
                    "middle": "中风",
                    "high": "高风",
                    "auto": "自动"
                },
                "default": "auto"
            }]
        },
        "0xB6": {
            "name": "抽油烟机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "gear",
                "propertyName": "档位",
                "type": "list",
                "value": {
                    "1": "1档",
                    "2": "2档",
                    "3": "3档",
                    "4": "4档"
                },
                "default": "1"
            }]
        },
        "0xB8": {
            "name": "吸尘器",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "work": "启动",
                    "stop": "停止",
                    "charge": "回充"
                },
                "default": "stop"
            }, {
                "property": "work_mode",
                "propertyName": "工作模式",
                "type": "list",
                "value": {
                    "random": "随机模式",
                    "arc": "弓形模式",
                    "edge": "沿边模式",
                    "emphases": "重点模式",
                    "screw": "螺旋模式",
                    "auto": "自动模式"
                },
                "default": "auto"
            }]
        },
        "0xA1": {
            "name": "除湿机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "set": "设定除湿",
                    "continuity": "连续除湿",
                    "auto": "自动除湿",
                    "dry_clothes": "干衣模式",
                    "dry_shoes": "干鞋模式"
                },
                "default": "auto"
            }]
        },
        "0x10": {
            "name": "插座",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        },
        "0x13": {
            "name": "WiFi吸顶灯",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        }
    },
    '3': {
        "0xAC": {
            "name": "空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xCC": {
            "name": "中央空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xE1": {
            "name": "洗碗机",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "soft_gear": "软水档位设置中",
                    "error": "错误",
                    "order": "预约",
                    "work": "开始工作",
                    "cancel": "取消工作",
                    "power_off": "关机",
                    "power_on": "开机"
                },
                "default": "power_off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "self_define": "自定义",
                    "fast_wash": "快速洗",
                    "glass_wash": "玻璃洗",
                    "eco_wash": "节能洗/经济洗",
                    "standard_wash": "及时洗/标准洗",
                    "strong_wash": "强力洗",
                    "auto_wash": "自动洗/智能洗"
                },
                "default": "auto_wash"
            }]
        },
        "0xE2": {
            "name": "热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 75,
                    "min": 30
                },
                "default": 65
            }]
        },
        "0xE3": {
            "name": "燃热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 65,
                    "min": 35
                },
                "default": 65
            }]
        },
        "0xFA": {
            "name": "风扇",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "normal": "正常风",
                    "natural": "自然风",
                    "sleep": "睡眠风",
                    "comfort": "舒适风",
                    "feel": "人感",
                    "baby": "宝宝风",
                    "mute": "静音风"
                },
                "default": "normal"
            }]
        },
        "0xFB": {
            "name": "电暖器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 50,
                    "min": -40
                },
                "default": 27
            }]
        },
        "0xFC": {
            "name": "空气净化器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "value": {
                    "auto": "自动",
                    "manual": "手动",
                    "sleep": "睡眠",
                    "fast": "急速"
                },
                "default": "auto"
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "range",
                "range": {
                    "max": 0,
                    "min": 101
                },
                "default": 101
            }]
        },
        "0xFD": {
            "name": "加湿器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "list",
                "value": {
                    "low": "低风",
                    "middle": "中风",
                    "high": "高风",
                    "auto": "自动"
                },
                "default": "auto"
            }]
        },
        "0xB6": {
            "name": "抽油烟机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "gear",
                "propertyName": "档位",
                "type": "list",
                "value": {
                    "1": "1档",
                    "2": "2档",
                    "3": "3档",
                    "4": "4档"
                },
                "default": "1"
            }]
        },
        "0xB8": {
            "name": "吸尘器",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "work": "启动",
                    "stop": "停止",
                    "charge": "回充"
                },
                "default": "stop"
            }, {
                "property": "work_mode",
                "propertyName": "工作模式",
                "type": "list",
                "value": {
                    "random": "随机模式",
                    "arc": "弓形模式",
                    "edge": "沿边模式",
                    "emphases": "重点模式",
                    "screw": "螺旋模式",
                    "auto": "自动模式"
                },
                "default": "auto"
            }]
        },
        "0xA1": {
            "name": "除湿机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "set": "设定除湿",
                    "continuity": "连续除湿",
                    "auto": "自动除湿",
                    "dry_clothes": "干衣模式",
                    "dry_shoes": "干鞋模式"
                },
                "default": "auto"
            }]
        },
        "0x10": {
            "name": "插座",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        },
        "0x13": {
            "name": "WiFi吸顶灯",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        }
    },
    '4': {
        "0xAC": {
            "name": "空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xCC": {
            "name": "中央空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xE1": {
            "name": "洗碗机",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "soft_gear": "软水档位设置中",
                    "error": "错误",
                    "order": "预约",
                    "work": "开始工作",
                    "cancel": "取消工作",
                    "power_off": "关机",
                    "power_on": "开机"
                },
                "default": "power_off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "self_define": "自定义",
                    "fast_wash": "快速洗",
                    "glass_wash": "玻璃洗",
                    "eco_wash": "节能洗/经济洗",
                    "standard_wash": "及时洗/标准洗",
                    "strong_wash": "强力洗",
                    "auto_wash": "自动洗/智能洗"
                },
                "default": "auto_wash"
            }]
        },
        "0xE2": {
            "name": "热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 75,
                    "min": 30
                },
                "default": 65
            }]
        },
        "0xE3": {
            "name": "燃热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 65,
                    "min": 35
                },
                "default": 65
            }]
        },
        "0xFA": {
            "name": "风扇",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "normal": "正常风",
                    "natural": "自然风",
                    "sleep": "睡眠风",
                    "comfort": "舒适风",
                    "feel": "人感",
                    "baby": "宝宝风",
                    "mute": "静音风"
                },
                "default": "normal"
            }]
        },
        "0xFB": {
            "name": "电暖器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 50,
                    "min": -40
                },
                "default": 27
            }]
        },
        "0xFC": {
            "name": "空气净化器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "value": {
                    "auto": "自动",
                    "manual": "手动",
                    "sleep": "睡眠",
                    "fast": "急速"
                }
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "range",
                "range": {
                    "max": 0,
                    "min": 101
                },
                "default": 101
            }]
        },
        "0xFD": {
            "name": "加湿器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "list",
                "value": {
                    "low": "低风",
                    "middle": "中风",
                    "high": "高风",
                    "auto": "自动"
                },
                "default": "auto"
            }]
        },
        "0xB6": {
            "name": "抽油烟机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "gear",
                "propertyName": "档位",
                "type": "list",
                "value": {
                    "1": "1档",
                    "2": "2档",
                    "3": "3档",
                    "4": "4档"
                },
                "default": "1"
            }]
        },
        "0xB8": {
            "name": "吸尘器",
            "actions": [{
                "property": "work_status",
                "propertyName": "工作状态",
                "type": "list",
                "value": {
                    "work": "启动",
                    "stop": "停止",
                    "charge": "回充"
                },
                "default": "stop"
            }, {
                "property": "work_mode",
                "propertyName": "工作模式",
                "type": "list",
                "value": {
                    "random": "随机模式",
                    "arc": "弓形模式",
                    "edge": "沿边模式",
                    "emphases": "重点模式",
                    "screw": "螺旋模式",
                    "auto": "自动模式"
                },
                "default": "auto"
            }]
        },
        "0xA1": {
            "name": "除湿机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "set": "设定除湿",
                    "continuity": "连续除湿",
                    "auto": "自动除湿",
                    "dry_clothes": "干衣模式",
                    "dry_shoes": "干鞋模式"
                },
                "default": "auto"
            }]
        },
        "0x10": {
            "name": "插座",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        },
        "0x13": {
            "name": "WiFi吸顶灯",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        }
    },
    '6': {
        "0xAC": {
            "name": "空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xCC": {
            "name": "中央空调",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "auto": "自动",
                    "fan": "送风",
                    "cool": "制冷",
                    "heat": "制热",
                    "dry": "抽湿"
                },
                "default": "auto"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 30,
                    "min": 17
                },
                "default": 27
            }]
        },
        "0xE2": {
            "name": "热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 75,
                    "min": 30
                },
                "default": 65
            }]
        },
        "0xE3": {
            "name": "燃热水器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 65,
                    "min": 35
                },
                "default": 65
            }]
        },
        "0xFA": {
            "name": "风扇",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "normal": "正常风",
                    "natural": "自然风",
                    "sleep": "睡眠风",
                    "comfort": "舒适风",
                    "feel": "人感",
                    "baby": "宝宝风",
                    "mute": "静音风"
                },
                "default": "normal"
            }]
        },
        "0xFB": {
            "name": "电暖器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "temperature",
                "propertyName": "温度",
                "type": "range",
                "range": {
                    "max": 50,
                    "min": -40
                },
                "default": 27
            }]
        },
        "0xFC": {
            "name": "空气净化器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "value": {
                    "auto": "自动",
                    "manual": "手动",
                    "sleep": "睡眠",
                    "fast": "急速"
                }
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "range",
                "range": {
                    "max": 0,
                    "min": 101
                },
                "default": 101
            }]
        },
        "0xFD": {
            "name": "加湿器",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "wind_speed",
                "propertyName": "风速",
                "type": "list",
                "value": {
                    "low": "低风",
                    "middle": "中风",
                    "high": "高风",
                    "auto": "自动"
                },
                "default": "auto"
            }]
        },
        "0xA1": {
            "name": "除湿机",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }, {
                "property": "mode",
                "propertyName": "模式",
                "type": "list",
                "value": {
                    "set": "设定除湿",
                    "continuity": "连续除湿",
                    "auto": "自动除湿",
                    "dry_clothes": "干衣模式",
                    "dry_shoes": "干鞋模式"
                },
                "default": "auto"
            }]
        },
        "0x10": {
            "name": "插座",
            "actions": [{
                "property": "power",
                "propertyName": "电源",
                "type": "switch",
                "value": {
                    "off": "关机",
                    "on": "开机"
                },
                "default": "off"
            }]
        }
    }
};

var applianceImgPath = exports.applianceImgPath = {
    "0xAC": "assets/img/0xAC.png", //空调
    "0xCC": "assets/img/0xCC.png", //中央空调
    "0xE1": "assets/img/0xE1.png", //洗碗机
    "0xE2": "assets/img/0xE2.png", //热水器
    "0xE3": "assets/img/0xE3.png", //燃热水器
    "0xFB": "assets/img/0xFB.png", //电暖器
    "0xB6": "assets/img/0xB6.png", //抽油烟机
    "0xB8": "assets/img/0xB8.png", //吸尘器
    "0xFC": "assets/img/0xFC.png", //空气净化器
    "0xFA": "assets/img/0xFA.png", //风扇
    "0xFD": "assets/img/0xFD.png", //加湿器
    "0xA1": "assets/img/0xA1.png", //除湿机
    "0x10": "assets/img/0x10.png", //插座
    "0x13": "assets/img/0x13.png" //吸顶灯
};

/***/ })

/******/ });